import MainPage from "./MainPage";
import NotFoundPage from "./NotFoundPage";

export {MainPage, NotFoundPage};