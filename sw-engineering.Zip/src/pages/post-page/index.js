import PostDetailPage from "./PostDetailPage";
import PostListPage from "./PostListPage";
import PostWritePage from "./PostWritePage";

export {PostDetailPage, PostListPage, PostWritePage};